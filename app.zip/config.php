<?php
$conn=mysqli_connect("localhost", "id18486238_maajiuser2", "_GhuXI2S1+dZY<V8", "id18486238_maaji2");

if($conn){
  
}
else{
    echo "Something went wrong, please try again!";

}
?>