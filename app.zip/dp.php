<?php
function dp($cid){


if ($cid=="+2347026662066") {
 $dp="ibrahim.jpg";
 echo $dp;
}
elseif ($cid=="+2348162224407") {
    $dp="prince.jpg";
echo $dp;
  
}
elseif ($cid=="+2348101029771") {
    $dp="kene.jpg";
echo $dp;
  
}




elseif ($cid=="+2348082905659") {
    $dp="suraj.jpg";
echo $dp;
  
}
else {
    $dp="avatar.png";
echo $dp;
}

}

?>